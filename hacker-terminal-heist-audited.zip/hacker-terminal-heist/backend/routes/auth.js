'use strict';
// Simple per-IP rate limiter (no extra dependency). Sessions are anonymous; tokens are issued by POST /api/session.
const hits = new Map();
function rateLimit({ windowMs = 60000, max = 120 } = {}) {
  return (req, res, next) => {
    const now = Date.now(), k = req.ip;
    let h = hits.get(k);
    if (!h || now > h.reset) h = { n: 0, reset: now + windowMs };
    h.n++; hits.set(k, h);
    if (hits.size > 5000) for (const [key, v] of hits) if (now > v.reset) hits.delete(key);
    if (h.n > max) return res.status(429).json({ error: { code: 'RATE_LIMITED', message: 'Too many requests. Slow down.' } });
    next();
  };
}
module.exports = { rateLimit };
