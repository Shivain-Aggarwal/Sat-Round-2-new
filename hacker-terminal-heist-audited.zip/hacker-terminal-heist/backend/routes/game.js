'use strict';
const express = require('express');
const { auth, sign } = require('../middleware/auth');
const E = require('../engine/state');
const sentinel = require('../../ai/sentinel');

const router = express.Router();
const leaderboard = []; // in-memory: resets on restart (see README)
const err = (res, status, code, message, extra = {}) => res.status(status).json({ error: { code, message }, ...extra });
const wrap = fn => (req, res, next) => fn(req, res, next).catch(next);

router.post('/session', (req, res) => {
  const s = E.createSession();
  res.json({ token: sign(s.id), state: E.view(s) });
});
router.get('/state', auth, (req, res) => res.json({ state: E.view(req.session) }));

router.post('/command', auth, wrap(async (req, res) => {
  const cmd = req.body && req.body.command;
  if (typeof cmd !== 'string') return err(res, 400, 'BAD_REQUEST', 'Expected JSON {"command": string}.');
  const r = E.execute(req.session, cmd);
  if (r.locked) return err(res, 423, 'LOCKED', 'Terminal locked by SENTINEL.', { state: E.view(req.session) });
  const line = await sentinel.line(r.events, req.session);
  res.json({ out: r.out, clear: !!r.clear, sentinel: line, state: E.view(req.session) });
}));

router.post('/hint', auth, wrap(async (req, res) => {
  const r = E.hint(req.session);
  if (r.locked) return err(res, 423, 'LOCKED', 'Terminal locked by SENTINEL.', { state: E.view(req.session) });
  res.json({ out: r.out, sentinel: await sentinel.line(r.events, req.session), state: E.view(req.session) });
}));

router.get('/sentinel', auth, wrap(async (req, res) => {
  res.json({ sentinel: await sentinel.line(['high'], req.session) });
}));

router.post('/mission/complete', auth, (req, res) => {
  const r = E.advance(req.session);
  if (!r.ok) return err(res, 409, 'NOT_COMPLETE', r.reason);
  res.json({ out: r.out, sentinel: req.session.finished ? sentinel.LINES.finished[0] : null, state: E.view(req.session) });
});

router.post('/score', auth, (req, res) => {
  const s = req.session;
  if (!s.finished) return err(res, 409, 'NOT_FINISHED', 'Finish all missions first.');
  if (s.submitted) return err(res, 409, 'ALREADY_SUBMITTED', 'Score already submitted.');
  const name = req.body && req.body.name;
  if (typeof name !== 'string' || !/^[A-Za-z0-9_ -]{1,16}$/.test(name.trim())) return err(res, 400, 'BAD_NAME', 'Name: 1-16 letters, digits, space, _ or -.');
  s.submitted = true; // score comes from the server, never the request body
  leaderboard.push({ name: name.trim(), score: s.score, time: E.view(s).stats.elapsed });
  leaderboard.sort((a, b) => b.score - a.score);
  leaderboard.length = Math.min(leaderboard.length, 50);
  res.json({ ok: true, state: E.view(s) });
});

router.get('/leaderboard', (req, res) => res.json({ entries: leaderboard.slice(0, 10) }));

module.exports = { router, leaderboard };
