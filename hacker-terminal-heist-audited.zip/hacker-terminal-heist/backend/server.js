'use strict';
const path = require('path');
const express = require('express');
const { router } = require('./routes/game');
const { rateLimit } = require('./routes/auth');

const CSP = ["default-src 'self'", "style-src 'self' https://fonts.googleapis.com", "font-src https://fonts.gstatic.com", "img-src 'self' data:",
  "connect-src 'self'", "base-uri 'none'", "form-action 'self'", "frame-ancestors 'none'"].join('; ');

function createApp() {
  const app = express();
  app.disable('x-powered-by');
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Content-Security-Policy', CSP);
    next();
  });
  app.use('/api', (req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); });
  app.use(express.json({ limit: '2kb' }));
  app.use('/api', rateLimit(), router);
  app.use('/api', (req, res) => res.status(404).json({ error: { code: 'NOT_FOUND', message: 'No such endpoint.' } }));
  app.use(express.static(path.join(__dirname, '..', 'frontend')));
  // eslint-disable-next-line no-unused-vars
  app.use((e, req, res, next) => {
    if (e.type === 'entity.parse.failed') return res.status(400).json({ error: { code: 'BAD_JSON', message: 'Malformed JSON.' } });
    if (e.type === 'entity.too.large') return res.status(413).json({ error: { code: 'TOO_LARGE', message: 'Request too large.' } });
    console.error(e);
    res.status(500).json({ error: { code: 'SERVER_ERROR', message: 'Internal error.' } });
  });
  return app;
}

if (require.main === module) {
  const port = process.env.PORT || 3000;
  createApp().listen(port, () => console.log(`NEXUS shell listening on http://localhost:${port}`));
}
module.exports = { createApp };
